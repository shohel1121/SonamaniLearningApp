সোনামণি শেখা — Android App

এই প্রজেক্ট GitHub Actions দিয়ে APK তৈরি করার জন্য প্রস্তুত।
প্রধান অ্যাপ: app/src/main/assets/index.html
