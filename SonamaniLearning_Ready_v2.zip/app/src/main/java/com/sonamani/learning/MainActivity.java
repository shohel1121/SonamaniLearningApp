package com.sonamani.learning;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) tts.setLanguage(new Locale("bn", "BD"));
        });

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void speakText(String text, String lang, String type, float rate, float pitch) {
            runOnUiThread(() -> {
                if (tts == null || !ttsReady) {
                    Toast.makeText(MainActivity.this, "ফোনের Text-to-Speech প্রস্তুত হচ্ছে—একটু পরে আবার চাপুন।", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Locale locale = (lang != null && lang.toLowerCase(Locale.ROOT).startsWith("en"))
                            ? Locale.US : new Locale("bn", "BD");
                    tts.setLanguage(locale);
                    float p = pitch;
                    if ("child".equals(type)) p = Math.max(1.15f, pitch);
                    else if ("female".equals(type)) p = Math.max(1.05f, pitch);
                    else p = Math.min(1.0f, pitch);
                    tts.setPitch(p);
                    tts.setSpeechRate(Math.max(0.4f, Math.min(1.5f, rate)));
                    tts.stop();
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonamani");
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ভয়েস চালু করা যায়নি। ফোনের Text-to-Speech সেটিংস দেখুন।", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void stopSpeech() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void openTTSSettings() {
            try {
                startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
            } catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { }
            }
        }

        @JavascriptInterface
        public String getTTSVoices() {
            JSONArray arr = new JSONArray();
            if (tts != null && ttsReady) {
                try {
                    for (Voice v : tts.getVoices()) {
                        JSONObject o = new JSONObject();
                        o.put("name", v.getName());
                        o.put("locale", v.getLocale().toLanguageTag());
                        arr.put(o);
                    }
                } catch (Exception ignored) { }
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void saveHtmlFile(String filename, String text) {
            try {
                String safe = filename.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (!safe.toLowerCase(Locale.ROOT).endsWith(".html")) safe += ".html";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, "text/html");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Could not create download");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open output");
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "ফাইল Downloads ফোল্ডারে সংরক্ষণ হয়েছে", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "ফাইল সংরক্ষণ করা যায়নি: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
