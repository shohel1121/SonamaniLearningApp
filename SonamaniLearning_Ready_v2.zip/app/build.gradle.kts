plugins {
    id("com.android.application")
}

android {
    namespace = "com.sonamani.learning"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sonamani.learning"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
